import React from "react";
import Button from "react-bootstrap/Button";
import "./Login.css"
import Card from "react-bootstrap/Card";

const Login = props => {


    return (
        <>
            <div id="d1">
            <section id="sect" className="clean-block clean-form mt-5 bg-light text-center" style={{ width: '40rem'}}>
                <div className="container" >
                    <Card>
                        <Card.Header>
                            <h2>Log in panel</h2>
                        </Card.Header>
                        <Card.Body>
                            <reactForm>
                                <div className="form-group text-left">
                                    <label htmlFor="email">Email</label>
                                    <input id="email" className="form-control item" type="email"/>
                                </div>
                                <div className="form-group text-left">
                                    <label htmlFor="password">Password</label>
                                    <input id="password" className="form-control" type="password"/>
                                </div>
                            </reactForm>
                        </Card.Body>
                        <Card.Footer>
                            <Button className="mb-1 " variant="success" type="submit" size="lg">Log In</Button>
                        </Card.Footer>
                    </Card>
                    {/*
                    <div id="naglowek" className="block-heading mt-4">
                        <h2>Log in</h2>
                    </div>
                    <reactForm>
                        <div className="form-group text-left">
                            <label for="email">Email</label>
                            <input id="email" className="form-control item" type="email"/>
                        </div>
                        <div className="form-group text-left">
                            <label for="password">Password</label>
                            <input id="password" className="form-control" type="password"/>
                        </div>
                        <Button className="width-auto mb-4" variant="success" type="submit">Log In</Button>
                    </reactForm>
                    */}
                    </div>

            </section>
            </div>
            </>
    );
}

export default Login;
