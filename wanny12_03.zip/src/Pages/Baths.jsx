import React from "react";

import Bath from "../Components/Bath/Bath";
import Row from "react-bootstrap/Row";


const Baths = props => {

    const renderBath = () => {
        const NR_OF_BATHS = 15;
        let baths = [];

        for (let i=0; i < NR_OF_BATHS; i++) {
            baths.push(<Bath index={i+1} />);
        }

        return <Row>{baths}</Row>;
    };

    return (
        <>
            <div>Ustawienia wanien</div>
        <div>{renderBath()} </div>
        </>
);
}

export default Baths;
