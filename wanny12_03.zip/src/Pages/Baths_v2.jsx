import React from "react";

import Bath from "../Components/Bath_v2/Bath";


const Baths = props => {

    const renderBath = () => {
        let baths = [];
        baths.push(<Bath index={1} />)

        return <div>{baths}</div>;
    }

    return <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: '100%', marginTop: '5rem' }}><container>{renderBath()} </container></div>
}

export default Baths;
