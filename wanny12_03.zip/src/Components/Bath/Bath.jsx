import React from "react";
import "./Bath.module.css";


import {Button, Card, Col, Form, Modal, Row, Table} from "react-bootstrap";



const Bath = props => {


  return (
      <>
        <Col className="mt-2 mb-2" md="3" as={Card} border="light" text="center">
          <Card.Header>Wanna: {props.index}</Card.Header>
          <Card.Body>
            <Table className="w-100">
              <tr>
                <td className="w-25">Napiecie</td>
                <td className="w-10"> min: </td>
                <td className="w-10">1234</td>
                <td className="w-10"> max: </td>
                <td className="w-10">1234</td>
                <td className="w-10">V</td>
              </tr>
              <tr>
                <td className="w-25">Prad</td>
                <td className="w-10"> min: </td>
                <td className="w-10">1234</td>
                <td className="w-10"> max: </td>
                <td className="w-10">1234</td>
                <td className="w-10">A</td>
              </tr>
              <tr>
                <td className="w-25">Temperatura</td>
                <td className="w-10"> min: </td>
                <td className="w-10">1234</td>
                <td className="w-10"> max: </td>
                <td className="w-10">1234</td>
                <td className="w-10">C</td>
              </tr>
              <tr>
                <td className="w-25">Czas</td><td className="w-10"> min: </td>
                <td className="w-10">1234</td>
                <td className="w-10"> max: </td>
                <td className="w-10">1234</td>
                <td className="w-10">min</td>
              </tr>
              <tr>
                <td className="w-25">Stan stanowiska</td>
                <td className="w-10"> min: </td>
                <td className="w-10">1234</td>
                <td className="w-10"> max: </td>
                <td className="w-10">1234</td>
                <td className="w-10">OK</td>
              </tr>
            </Table>
          </Card.Body>
        </Col>
        </>
  );
};

export default Bath;
