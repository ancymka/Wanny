
import React, { Component } from 'react';
import Button from "react-bootstrap/Button";

class Clock1 extends Component {

    constructor() {
        super()
        this.state={time:new Date()}
    }

    currentTime()
    {
        this.setState({
            time: new Date()
        })
    }
    componentWillMount()
    {
        setInterval(()=>this.currentTime(),1000)
    }


    render() {

        return (
            <Button variant="outline-first" className="text-center align-content-center" disabled>
            <h8>
                CT:&nbsp;
                {this.state.time.toLocaleTimeString()}
            </h8>
            </Button>
        )
    }
}

export default Clock1;
