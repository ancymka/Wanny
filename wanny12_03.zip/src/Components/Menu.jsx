import React from 'react';
import { Navbar, Nav, NavItem, Button } from 'react-bootstrap';
import { LinkContainer } from 'react-router-bootstrap';
import Clock1 from "./Clock";


const Menu = () => {
    return (
        <Navbar id="menu" bg="light" expand="md" collapseOnSelect>
            <Navbar.Brand>
                Nazwa programu
            </Navbar.Brand>
            <Navbar.Toggle/>
            <Navbar.Collapse>
                <Nav className="mr-auto">
                    <LinkContainer as={Button}  variant="outline-dark" to="/stanowiska" className="ml-2">
                        <NavItem>Stands</NavItem>
                    </LinkContainer>
                    <LinkContainer as={Button}  variant="outline-dark" to="/wanny" className="ml-2">
                        <NavItem>Baths</NavItem>
                    </LinkContainer>
                    <LinkContainer as={Button}  variant="outline-dark" to="/archiwum" className="ml-2">
                    <NavItem>Archive</NavItem>
                    </LinkContainer>
                </Nav>
                <Nav>
                    <NavItem className="mr-2"><Clock1/></NavItem>
                    <LinkContainer as={Button}  variant="outline-dark" to="/login" className="mr-2">
                        <NavItem>Log in</NavItem>
                    </LinkContainer>
                    <NavItem as={Button} variant="outline-info" className="mr-2">PL</NavItem>

                </Nav>
            </Navbar.Collapse>
        </Navbar>
    )
}

export default Menu;
